import os
import sys
import json

test_json_file = sys.argv[1]

f = open(test_json_file)
test_data = json.load(f)
for scenario in test_data['Scenario']:
    print('Creating feature file',scenario['name'])
    file=open(f'{os.getcwd()}\\app\Features\{scenario["name"]}.feature', 'w')
    file.write(f"Feature: {scenario['name']}\n\n")
    for test in scenario['Test_case']:
        file.write(f'Scenario: {scenario["name"]} of two number\n')
        file.write(f'   Given Two number for {scenario["name"]}\n')
        file.write(f'   When Entered given number {test["a"]} and {test["b"]}\n')
        file.write(f'   Then {scenario["name"]} of two number {test["ans"]}\n\n')
    file.close()
    print('Created feature file', scenario['name'])

print("Running Tests")

print(os.system('venv\Scripts\\activate && cd app && behave -f html -o behave-report.html'))

print("Test completed Please check behave-report.html")