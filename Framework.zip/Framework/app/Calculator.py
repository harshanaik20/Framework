import sys


class Calculatoor():

    def add(self, x, y):
        return x + y


    def subtract(self, x, y):
        return x - y


    def multiply(self, x, y):
        return x * y


    def divide(self, x, y):
        x=float(x)
        y=float(y)
        try:
            return x / y
        except Exception as e:
            if y == 0:
                return 'division by zero'
            return e



try:
    argv = sys.argv
    c = Calculatoor()
    a = int(argv[2])
    b = int(argv[3])
    #print('a=',a,'  b=',b)
    if argv[1].lower() == 'add':
        print(c.add(a, b))
    elif argv[1].lower() == 'sub':
        print(c.subtract(a, b))
    elif argv[1].lower() == 'mul':
        print(c.multiply(a, b))
    elif argv[1].lower() == 'div':
        print(c.divide(a, b))
    else:
        print("not valid operation")

except:
    print("not valid")