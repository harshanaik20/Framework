import time

from behave import *
import logging
import os

feature=1

@given(u'Two number for {op}')
def step_impl(context,op):
    if op== 'Addition':
        context.op= 'add'
    elif op == 'subtract':
        context.op = 'sub'
    elif op == 'multiply':
        context.op = 'mul'
    elif op == 'divide':
        context.op = 'div'
    else:
        raise RuntimeError('Not valid operation')


@when(u'Entered given number {a} and {b}')
def step_impl(context, a, b):
    context.file= f'feature{feature}.txt'
    logging.info(f'python Calculator.py {context.op} {a} {b} > {context.file}')
    os.system(f'python Calculator.py {context.op} {a} {b} > {context.file}')

    #print(context)


@then(u'{op} of two number {ans}')
def step_impl(context, op, ans):
    f=open(context.file)
    #logging.error(f.read())
    aans=f.readline().strip()
    f.close()
    time.sleep(1)
    if float(ans) == float(aans):
        pass
    else:
        logging.error(f'expected = {ans} actual {aans}')
        assert False
